#! /usr/bin/python
# -*- coding: utf-8 -*-

name = "HARIX_RDK"

import sys

if sys.version_info < (3, 5, 1):
    sys.exit('harix rdk requires Python 3.5.1 or later')
